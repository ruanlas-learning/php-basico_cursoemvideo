<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8"/>
  <link rel="stylesheet" href="_css/estilo.css"/>
  <title></title>
</head>
<body>
<div>
    <?php
       $n1 = 3;
       $n2 = 2;
       $s = $n1 + $n2;
       echo "A soma entre $n1 e $n2 e igual a $s";
    ?>
</div>
</body>
</html>
 