﻿<html>
	<body>
		<?php
			echo "Oi";
		?>
	</body>
</html>